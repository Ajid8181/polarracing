document.getElementById('toggleMode').addEventListener('click', function() {
    document.body.classList.toggle('light-mode');
    if (document.body.classList.contains('light-mode')) {
        this.textContent = '🌙 Mode Gelap';
    } else {
        this.textContent = '☀️ Mode Terang';
    }
});